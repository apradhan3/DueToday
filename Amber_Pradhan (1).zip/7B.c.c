#include<stdio.h>
int
main ()
{
  int a = 50, b = 20, c = 30;
  if (a > b && b > c)
    printf ("True\n");
  else
    printf ("False\n");
}


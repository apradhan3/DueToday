#include<stdio.h>
int main()
{
int a=4,b=3,c=2;
if(a>b>c)
    printf("True\n");
else
    printf("False\n");
}
